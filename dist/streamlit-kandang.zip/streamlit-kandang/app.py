"""Antarmuka Streamlit untuk generator konsep kandang close house."""

from __future__ import annotations

import math
import os

import streamlit as st

from trust_client import TrustAPIError, generate_image


LIVESTOCK_OPTIONS = ("Ayam broiler", "Ayam petelur", "Bebek pedaging")
FEATURE_OPTIONS = (
    "Cooling pad",
    "Exhaust fan",
    "Jalur pakan otomatis",
    "Nipple drinker",
    "Zona biosekuriti",
)
STYLE_OPTIONS = (
    "Sketsa pensil arsitektural",
    "Render realistis",
    "Ilustrasi isometrik teknis",
)


def validate_dimensions(length_m: float, width_m: float) -> None:
    """Validasi setiap sisi kandang dalam rentang aman 1–200 meter."""
    if not all(math.isfinite(value) for value in (length_m, width_m)):
        raise ValueError("Dimensi harus berupa angka yang valid.")
    if not all(1 <= value <= 200 for value in (length_m, width_m)):
        raise ValueError("Panjang dan lebar harus antara 1 hingga 200 meter.")


def calculate_area(length_m: float, width_m: float) -> float:
    """Hitung luas kandang dalam meter persegi."""
    validate_dimensions(length_m, width_m)
    return round(length_m * width_m, 2)


def _format_number(value: float) -> str:
    return f"{value:g}"


def build_prompt(
    length_m: float,
    width_m: float,
    livestock: str,
    features: list[str],
    style: str,
) -> str:
    """Bangun prompt gambar hanya dari pilihan UI yang telah dibatasi."""
    validate_dimensions(length_m, width_m)
    if livestock not in LIVESTOCK_OPTIONS:
        raise ValueError("Jenis ternak tidak tersedia.")
    if style not in STYLE_OPTIONS:
        raise ValueError("Gaya visual tidak tersedia.")
    if any(feature not in FEATURE_OPTIONS for feature in features):
        raise ValueError("Ada fitur kandang yang tidak tersedia.")

    area = calculate_area(length_m, width_m)
    ratio = max(length_m, width_m) / min(length_m, width_m)
    feature_text = ", ".join(features) if features else "tanpa peralatan tambahan"
    shape_instruction = ""
    if ratio >= 2:
        shape_instruction = (
            " Denah harus tampak berbentuk memanjang sesuai proporsi; "
            "jangan menggambarkannya sebagai bangunan persegi."
        )

    ventilation = ""
    if "Cooling pad" in features:
        ventilation += (
            " Cooling pad adalah deret panel selulosa sarang lebah basah dalam bingkai "
            "pada dinding ujung pendek sisi masuk udara; tampakkan permukaan panel "
            "di sisi luar dan talang air di bawahnya, bukan pintu, kipas, atau panel "
            "yang berdiri sendiri di tengah kandang. Jika ada tanda atau panah "
            "bertuliskan 'Cooling pad', ujung panah harus tepat menyentuh panel "
            "sarang lebah pada sisi inlet tersebut, bukan kipas, pintu, atap, atau "
            "peralatan di dalam kandang; jika tidak bisa ditunjuk tepat, hilangkan "
            "tanda dan panah tetapi tetap tampilkan panelnya."
        )
    if "Exhaust fan" in features:
        ventilation += (
            " Exhaust fan berupa kipas aksial berbingkai dengan bilah dan kisi pelindung "
            "yang terpasang menembus dinding ujung pendek sisi buang, bukan pintu, "
            "jendela, atau kipas berdiri bebas di dalam kandang."
        )
    if "Cooling pad" in features and "Exhaust fan" in features:
        ventilation += (
            " Tempatkan pad dan kipas di ujung berlawanan agar aliran udara "
            "memanjang melalui kandang, tanpa pintu menembus keduanya."
        )
    equipment = ""
    if "Jalur pakan otomatis" in features:
        equipment += (
            " Jalur pakan otomatis berupa pipa dan deret pan feeder sejajar sumbu "
            "panjang di atas lantai area ternak, tersambung ke silo di luar kandang."
        )
    if "Nipple drinker" in features:
        equipment += (
            " Nipple drinker berupa deret pipa air dengan nipple yang digantung "
            "sejajar sumbu panjang kandang, pada ketinggian terjangkau ternak; "
            "bukan keran dinding."
        )
    if "Jalur pakan otomatis" in features and "Nipple drinker" in features:
        equipment += " Pisahkan jalur pakan dan jalur minum agar keduanya terlihat utuh."
    livestock_detail = (
        " Ayam broiler berada di lantai beralas sekam kering, tanpa kandang baterai."
        if livestock == "Ayam broiler" else
        " Ayam petelur ditampilkan dengan sistem lantai, alas litter dan sarang bertelur; "
        "jangan campur dengan kandang baterai."
        if livestock == "Ayam petelur" else
        " Bebek pedaging berada di lantai beralas litter kering, bukan di kolam air."
    )
    biosecurity = (
        " Zona biosekuriti adalah ruang masuk kecil tertutup yang menempel di LUAR "
        "dinding samping kandang, di depan pintu akses pekerja, dengan pintu luar "
        "dan pintu dalam terpisah serta tempat ganti alas kaki dan cuci tangan. "
        "Jangan letakkan zona biosekuriti, pos keamanan, atau ruang ganti di dalam "
        "area ternak; jangan tampilkan petugas keamanan atau pagar di dalam kandang."
        if "Zona biosekuriti" in features else ""
    )
    realism = (
        " Render fotorealistis dengan material dan skala bangunan masuk akal, "
        "pencahayaan alami dan detail konstruksi nyata."
        if style == "Render realistis" else ""
    )

    return (
        f"Buat gambar konsep kandang close house untuk {livestock}. "
        f"Dimensi pasti: panjang {_format_number(length_m)} meter dan lebar "
        f"{_format_number(width_m)} meter, luas {area:g} meter persegi."
        f"{shape_instruction} Fitur yang terlihat: {feature_text}. "
        "Rancang sebagai kandang tertutup yang dapat dibangun: atap miring, dinding, "
        "lantai, akses servis dan peralatan berskala konsisten; deret peralatan "
        "berulang mengikuti panjang bangunan, bukan satu perangkat raksasa. "
        "Potongan atap hanya alat visualisasi, bukan lubang pada kandang jadi; "
        "dinding dan ventilasi tetap rapat sesuai fungsi kandang tertutup. "
        "Pintu akses pekerja di sisi samping, bukan tepat di area inlet atau outlet ventilasi. "
        "Jangan tambahkan pintu dekoratif, pintu di balik perangkat ventilasi, atau bukaan "
        "yang memutus aliran udara. Perlihatkan hanya peralatan yang dipilih. "
        "Gunakan satu sudut pandang isometrik potongan atap: sebagian atap diangkat "
        "hanya secara visual, tiga sisi bangunan tetap terbaca, seluruh panjang lantai "
        "dan setiap fitur yang dipilih tampak tanpa tertutup atap atau dinding. "
        "Pertahankan dinding sebagai batas fisik yang jelas: peralatan ternak di dalam, "
        "perangkat eksterior di luar; jangan pindahkan fitur ke tengah kandang demi "
        "memperlihatkannya. Jangan tambahkan bangunan, orang, atau perangkat "
        "yang tidak diperlukan."
        f"{ventilation}{equipment}{biosecurity}{livestock_detail} Gaya visual: {style}.{realism} "
        "Tampilkan struktur, ventilasi, dan tata letak secara jelas. " 
        "Hindari teks kecil atau label yang sulit dibaca; dimensi "
        "pada gambar hanyalah ilustrasi dan perlu diverifikasi."
    )


def get_api_key() -> str | None:
    """Ambil API key tanpa mencetak atau mengekspos nilainya."""
    env_key = os.getenv("TRUST_API_KEY", "").strip()
    if env_key:
        return env_key
    try:
        secret_key = str(st.secrets.get("TRUST_API_KEY", "")).strip()
    except (FileNotFoundError, KeyError):
        secret_key = ""
    return secret_key or None


def main() -> None:
    st.set_page_config(page_title="Konsep Kandang Close House", page_icon="🐔")
    st.title("Generator Konsep Kandang Close House")
    st.caption("Buat visual konsep kandang memanjang berdasarkan ukuran dan fitur pilihan.")

    left, right = st.columns(2)
    with left:
        length_m = st.number_input("Panjang (meter)", 1.0, 200.0, 32.0, 0.5)
    with right:
        width_m = st.number_input("Lebar (meter)", 1.0, 200.0, 8.0, 0.5)

    livestock = st.selectbox("Jenis ternak", LIVESTOCK_OPTIONS)
    features = st.multiselect(
        "Fitur kandang",
        FEATURE_OPTIONS,
        default=["Cooling pad", "Exhaust fan", "Jalur pakan otomatis", "Nipple drinker"],
    )
    style = st.selectbox("Gaya visual", STYLE_OPTIONS)

    area = calculate_area(length_m, width_m)
    aspect_ratio = max(length_m, width_m) / min(length_m, width_m)
    st.info(f"Luas: **{area:g} m²** · Rasio sisi: **{aspect_ratio:.2f}:1**")
    st.warning(
        "Hasil adalah konsep visual, bukan gambar kerja konstruksi atau rekomendasi "
        "teknis. Teks dan dimensi yang dirender model harus diverifikasi."
    )

    if not st.button("Buat gambar konsep", type="primary"):
        return

    try:
        prompt = build_prompt(length_m, width_m, livestock, list(features), style)
    except ValueError as exc:
        st.error(str(exc))
        return

    st.subheader("Prompt yang digunakan")
    st.code(prompt, language=None)
    api_key = get_api_key()
    if not api_key:
        st.error(
            "TRUST_API_KEY belum dikonfigurasi. Atur environment variable atau "
            "tambahkan key ke .streamlit/secrets.toml."
        )
        return

    try:
        with st.spinner("Membuat gambar konsep…"):
            image_bytes = generate_image(prompt, api_key)
    except TrustAPIError as exc:
        st.error(str(exc))
        return

    st.image(image_bytes, caption="Hasil konsep kandang", use_container_width=True)
    st.download_button(
        "Unduh PNG",
        data=image_bytes,
        file_name="konsep-kandang-close-house.png",
        mime="image/png",
    )
    st.success("Gambar konsep berhasil dibuat.")


if __name__ == "__main__":
    main()
