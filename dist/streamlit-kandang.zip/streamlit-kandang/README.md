# Generator Konsep Kandang Close House

Aplikasi Streamlit berbahasa Indonesia untuk membuat gambar konsep kandang peternakan melalui API gambar Trust. Ukuran bawaan 32 × 8 meter menekankan bentuk memanjang, tetapi dimensi dapat diubah dalam rentang 1–200 meter.

> **Batasan:** hasil adalah konsep visual, bukan gambar kerja konstruksi, perhitungan struktur, estimasi kapasitas ternak, atau rekomendasi teknis. Tulisan dan label dimensi yang dibuat model gambar dapat keliru; verifikasi selalu terhadap angka luas di aplikasi.

## Fitur

- Dimensi, jenis ternak, fitur kandang, dan gaya visual dapat dipilih.
- Luas dihitung langsung dari panjang × lebar.
- Prompt lengkap ditampilkan kepada pengguna: cooling pad dan exhaust fan pada ujung berlawanan, jalur pakan dan nipple drinker terpisah di area ternak, serta zona biosekuriti berupa ruang transisi di luar dinding samping sebelum pintu masuk pekerja. Sudut pandang potongan atap meminta semua fitur pilihan terlihat tanpa memindahkan peralatan luar ke area ternak; detail lantai dan sarang disesuaikan dengan jenis ternak. Cooling pad digambarkan sebagai panel selulosa berbingkai dengan talang di bawahnya; exhaust fan sebagai kipas aksial yang menembus dinding, bukan pintu atau peralatan berdiri bebas. Potongan atap hanya untuk visualisasi, bukan lubang pada bangunan jadi. Penanda cooling pad diminta menunjuk tepat ke panel inlet, atau dihilangkan bila tidak akurat. Hasil tetap perlu diperiksa karena model gambar dapat mengabaikan instruksi tata letak dan penanda.
- Menggunakan `ENDPOINT` dari `.streamlit/secrets.toml` dan model `tig/image`.
- Mendukung respons gambar `b64_json` maupun URL.
- Preview dan unduhan PNG.
- Pesan kesalahan aman untuk konfigurasi, autentikasi, kredit, rate limit, jaringan, respons rusak, dan gambar invalid.

## Persyaratan

- Python 3.11 atau lebih baru
- API key Trust dengan akses ke model `tig/image`

## Instalasi dan menjalankan

```bash
python -m venv .venv
source .venv/bin/activate  # Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
export TRUST_API_KEY="isi-key-anda"  # Windows PowerShell: $env:TRUST_API_KEY="isi-key-anda"
streamlit run app.py
```

Alternatif konfigurasi Streamlit: buat `.streamlit/secrets.toml` secara lokal (berkas ini diabaikan Git):

```toml
TRUST_API_KEY = "isi-key-anda"
ENDPOINT = "https://api.trustisgold.web.id/v1/images/generations"
```

Environment variable `TRUST_API_KEY` diprioritaskan bila kedua metode diatur. Jangan masukkan API key ke source code, prompt, log, atau ZIP.

## Pengujian

Pengujian menggunakan mock dan tidak memanggil API berbayar:

```bash
python -m pytest -q
```

Uji startup headless:

```bash
streamlit run app.py --server.headless true --server.port 8501
```

Lalu buka `http://localhost:8501`.

## Kontrak API

Aplikasi mengirim satu permintaan dengan konfigurasi tetap berikut:

- model: `tig/image`
- size: `1024x1024`
- quality: `medium`
- n: `1`
- timeout: 180 detik

Gambar hasil dibatasi maksimum 20 MiB; JPEG/WebP dari API dikonversi menjadi PNG yang valid. Unduhan URL hanya menerima HTTPS ke alamat publik, menolak port khusus dan redirect, serta dibaca secara streaming. Respons API utama juga dibaca secara streaming dengan batas ukuran sebelum JSON diproses.

## Isi paket

Jalankan `python build_zip.py` untuk membuat `dist/streamlit-kandang.zip`. Paket distribusi hanya berisi source, konfigurasi non-rahasia, dokumentasi, dan tests. `.env`, `.streamlit/secrets.toml`, virtualenv, cache, gambar hasil, dan file rahasia tidak disertakan.
