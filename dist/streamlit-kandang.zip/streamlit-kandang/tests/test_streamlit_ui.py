from pathlib import Path

from streamlit.testing.v1 import AppTest


APP_PATH = Path(__file__).resolve().parents[1] / "app.py"


def test_app_starts_and_renders_primary_controls():
    app = AppTest.from_file(APP_PATH).run(timeout=10)
    assert not app.exception
    assert app.title[0].value == "Generator Konsep Kandang Close House"
    assert len(app.number_input) == 2
    assert app.number_input[0].value == 32.0
    assert app.number_input[1].value == 8.0
    assert app.info[0].value.startswith("Luas: **256 m²**")
    assert app.button[0].label == "Buat gambar konsep"


def test_generate_without_key_shows_safe_configuration_error(monkeypatch):
    monkeypatch.delenv("TRUST_API_KEY", raising=False)
    monkeypatch.setattr("streamlit.secrets", {})
    app = AppTest.from_file(APP_PATH)
    app.run(timeout=10)
    app.button[0].click().run(timeout=10)
    assert not app.exception
    assert "TRUST_API_KEY belum dikonfigurasi" in app.error[0].value
    assert len(app.code) == 1
