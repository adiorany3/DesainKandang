import pytest

from app import build_prompt, calculate_area, get_api_key, validate_dimensions


@pytest.mark.parametrize(
    ("length", "width", "area"),
    [(32, 8, 256.0), (10, 12, 120.0), (1.25, 2, 2.5)],
)
def test_calculate_area(length, width, area):
    assert calculate_area(length, width) == area


@pytest.mark.parametrize(
    ("length", "width"),
    [
        (0, 8),
        (-2, 3),
        (201, 3),
        (float("nan"), 2),
        (3, float("inf")),
    ],
)
def test_reject_invalid_dimensions(length, width):
    with pytest.raises(ValueError):
        validate_dimensions(length, width)


@pytest.mark.parametrize(("length", "width"), [(1, 1), (200, 200)])
def test_accept_dimension_boundaries(length, width):
    validate_dimensions(length, width)


def test_prompt_includes_dimensions_area_features_and_long_form():
    prompt = build_prompt(
        32,
        8,
        "Ayam broiler",
        ["Cooling pad", "Exhaust fan"],
        "Sketsa pensil arsitektural",
    )
    assert "32" in prompt and "8" in prompt and "256" in prompt
    assert "Cooling pad" in prompt and "Exhaust fan" in prompt
    assert "memanjang" in prompt.lower()
    assert "persegi" in prompt.lower()


def test_prompt_places_ventilation_without_impossible_end_doors():
    prompt = build_prompt(
        32, 8, "Ayam broiler", ["Cooling pad", "Exhaust fan", "Zona biosekuriti"],
        "Render realistis",
    )
    assert "ujung berlawanan" in prompt
    assert "panel selulosa sarang lebah" in prompt and "talang air" in prompt
    assert "kipas aksial berbingkai" in prompt and "menembus dinding" in prompt
    assert "bukan lubang pada kandang jadi" in prompt
    assert "ujung panah harus tepat menyentuh panel" in prompt
    assert "bukan kipas, pintu, atap" in prompt
    assert "hilangkan tanda dan panah" in prompt
    assert "bukan pintu" in prompt
    assert "pintu akses" in prompt
    assert "di LUAR" in prompt
    assert "di dalam area ternak" in prompt
    assert "pintu luar" in prompt and "pintu dalam" in prompt
    assert "fotorealistis" in prompt

def test_prompt_places_feed_water_and_biosecurity_in_distinct_areas():
    prompt = build_prompt(
        32, 8, "Ayam broiler",
        ["Cooling pad", "Exhaust fan", "Jalur pakan otomatis", "Nipple drinker", "Zona biosekuriti"],
        "Render realistis",
    )
    assert "pan feeder" in prompt and "silo di luar kandang" in prompt
    assert "pipa air" in prompt and "bukan keran dinding" in prompt
    assert "ruang masuk kecil tertutup" in prompt and "di LUAR" in prompt
    assert "potongan atap" in prompt
    assert "setiap fitur yang dipilih tampak" in prompt
    assert "peralatan ternak di dalam" in prompt and "perangkat eksterior di luar" in prompt
    assert "Pisahkan jalur pakan dan jalur minum" in prompt
    assert "sekam kering" in prompt


@pytest.mark.parametrize(
    ("livestock", "expected"),
    [("Ayam petelur", "sarang bertelur"), ("Bebek pedaging", "bukan di kolam air")],
)
def test_prompt_uses_consistent_livestock_housing(livestock, expected):
    prompt = build_prompt(32, 8, livestock, ["Nipple drinker"], "Render realistis")
    assert expected in prompt
    assert "sejajar sumbu panjang kandang" in prompt
    assert "Pisahkan jalur pakan dan jalur minum" not in prompt

def test_prompt_does_not_invent_unselected_ventilation_equipment():
    prompt = build_prompt(32, 8, "Bebek pedaging", [], "Render realistis")
    assert "cooling pad" not in prompt.lower()
    assert "exhaust fan" not in prompt.lower()
    assert "pintu" in prompt.lower()


def test_prompt_does_not_claim_elongated_for_near_square_plan():
    prompt = build_prompt(10, 8, "Ayam broiler", [], "Render realistis")
    assert "bentuk memanjang" not in prompt.lower()


def test_get_api_key_prefers_environment(monkeypatch):
    monkeypatch.setenv("TRUST_API_KEY", "env-key")
    monkeypatch.setattr("app.st.secrets", {"TRUST_API_KEY": "secret-key"})
    assert get_api_key() == "env-key"


def test_get_api_key_falls_back_to_streamlit_secrets(monkeypatch):
    monkeypatch.delenv("TRUST_API_KEY", raising=False)
    monkeypatch.setattr("app.st.secrets", {"TRUST_API_KEY": "secret-key"})
    assert get_api_key() == "secret-key"


def test_get_api_key_returns_none_when_missing_or_empty(monkeypatch):
    monkeypatch.delenv("TRUST_API_KEY", raising=False)
    monkeypatch.setattr("app.st.secrets", {})
    assert get_api_key() is None
    monkeypatch.setenv("TRUST_API_KEY", "   ")
    assert get_api_key() is None
