"""Klien aman untuk endpoint generasi gambar Trust."""

from __future__ import annotations

import base64
import binascii
import io
import ipaddress
import json
import socket
from collections.abc import Callable
from typing import Any
from urllib.parse import urlsplit

import requests
import streamlit as st
from PIL import Image, UnidentifiedImageError

MAX_IMAGE_BYTES = 20 * 1024 * 1024
MAX_API_RESPONSE_BYTES = 28 * 1024 * 1024
MAX_IMAGE_PIXELS = 16_000_000
CHUNK_BYTES = 64 * 1024


class TrustAPIError(RuntimeError):
    """Kesalahan publik yang aman ditampilkan pada antarmuka."""


def _read_limited(response: Any, maximum: int, label: str) -> bytes:
    """Baca respons streaming tanpa pernah melewati batas byte."""
    try:
        announced = int(response.headers.get("Content-Length", "0"))
    except (TypeError, ValueError):
        announced = 0
    if announced > maximum:
        raise TrustAPIError(f"{label} terlalu besar.")

    output = bytearray()
    for chunk in response.iter_content(chunk_size=CHUNK_BYTES):
        if not chunk:
            continue
        if len(output) + len(chunk) > maximum:
            raise TrustAPIError(f"{label} terlalu besar.")
        output.extend(chunk)
    return bytes(output)


def _validate_public_https_url(url: str) -> None:
    """Tolak URL non-HTTPS, kredensial, port khusus, dan alamat nonpublik."""
    try:
        parsed = urlsplit(url)
        host = parsed.hostname
        port = parsed.port
    except (TypeError, ValueError) as exc:
        raise TrustAPIError("URL gambar dari API tidak valid.") from exc
    if parsed.scheme != "https" or not host or parsed.username or parsed.password:
        raise TrustAPIError("URL gambar harus HTTPS dan tidak memuat kredensial.")
    if port not in (None, 443):
        raise TrustAPIError("URL gambar memakai port yang tidak diizinkan.")

    try:
        addresses = {item[4][0] for item in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)}
    except socket.gaierror as exc:
        raise TrustAPIError("Host URL gambar tidak dapat ditemukan.") from exc
    if not addresses:
        raise TrustAPIError("Host URL gambar tidak memiliki alamat yang valid.")
    try:
        if any(not ipaddress.ip_address(address).is_global for address in addresses):
            raise TrustAPIError("URL gambar mengarah ke jaringan yang tidak diizinkan.")
    except ValueError as exc:
        raise TrustAPIError("Alamat host URL gambar tidak valid.") from exc


def _validate_png(image_bytes: bytes) -> bytes:
    if not image_bytes:
        raise TrustAPIError("Data gambar kosong.")
    if len(image_bytes) > MAX_IMAGE_BYTES:
        raise TrustAPIError("Data gambar terlalu besar (maksimum 20 MiB).")
    try:
        with Image.open(io.BytesIO(image_bytes)) as image:
            if image.format not in {"PNG", "JPEG", "WEBP"}:
                raise TrustAPIError("Format gambar dari API tidak didukung.")
            width, height = image.size
            if width <= 0 or height <= 0 or width * height > MAX_IMAGE_PIXELS:
                raise TrustAPIError("Dimensi gambar terlalu besar atau tidak valid.")
            image.load()
            if image.format == "PNG":
                return image_bytes
            output = io.BytesIO()
            image.save(output, format="PNG")
            if output.tell() > MAX_IMAGE_BYTES:
                raise TrustAPIError("Data gambar terlalu besar (maksimum 20 MiB).")
            return output.getvalue()
    except Image.DecompressionBombError as exc:
        raise TrustAPIError("Dimensi gambar terlalu besar untuk diproses dengan aman.") from exc
    except (UnidentifiedImageError, OSError, ValueError) as exc:
        raise TrustAPIError("Berkas gambar dari API rusak atau tidak dapat dibaca.") from exc


def decode_image_response(
    payload: dict[str, Any],
    get_fn: Callable[..., Any] = requests.get,
    timeout_s: int = 180,
) -> bytes:
    """Dekode varian b64_json atau URL menjadi PNG tervalidasi."""
    try:
        item = payload["data"][0]
    except (KeyError, IndexError, TypeError) as exc:
        raise TrustAPIError("Respons API tidak memuat data gambar.") from exc

    if isinstance(item, dict) and item.get("b64_json"):
        encoded = item["b64_json"]
        if not isinstance(encoded, str) or len(encoded) > (MAX_IMAGE_BYTES * 4 // 3) + 8:
            raise TrustAPIError("Data gambar base64 terlalu besar atau tidak valid.")
        try:
            image_bytes = base64.b64decode(encoded, validate=True)
        except (binascii.Error, ValueError, TypeError) as exc:
            raise TrustAPIError("Data gambar base64 dari API tidak valid.") from exc
        return _validate_png(image_bytes)

    if isinstance(item, dict) and item.get("url"):
        url = item["url"]
        _validate_public_https_url(url)
        try:
            with get_fn(
                url,
                timeout=timeout_s,
                stream=True,
                allow_redirects=False,
            ) as response:
                if 300 <= response.status_code < 400:
                    raise TrustAPIError("Pengalihan URL gambar tidak diizinkan.")
                if response.status_code >= 400:
                    raise TrustAPIError("Server gambar menolak permintaan unduhan.")
                content_type = response.headers.get("Content-Type", "").lower()
                if not content_type.startswith("image/"):
                    raise TrustAPIError("Respons URL memiliki tipe konten yang bukan gambar.")
                image_bytes = _read_limited(response, MAX_IMAGE_BYTES, "Data gambar")
        except requests.Timeout as exc:
            raise TrustAPIError("Waktu unduh gambar habis. Silakan coba lagi.") from exc
        except requests.RequestException as exc:
            raise TrustAPIError("Gagal mengunduh gambar dari API.") from exc
        return _validate_png(image_bytes)

    raise TrustAPIError("Respons API tidak memuat base64 atau URL gambar.")


def generate_image(
    prompt: str,
    api_key: str,
    timeout_s: int = 180,
    post_fn: Callable[..., Any] = requests.post,
) -> bytes:
    """Kirim permintaan generasi ke Trust dan kembalikan PNG tervalidasi."""
    if not api_key or not api_key.strip():
        raise TrustAPIError("API key Trust belum dikonfigurasi.")
    try:
        endpoint = str(st.secrets.get("ENDPOINT", "")).strip()
    except (FileNotFoundError, KeyError):
        endpoint = ""
    try:
        parsed = urlsplit(endpoint)
        valid = (parsed.scheme == "https" and parsed.hostname and not parsed.username
                 and not parsed.password and parsed.port in (None, 443))
    except ValueError:
        valid = False
    if not valid:
        raise TrustAPIError("ENDPOINT harus berupa URL HTTPS yang valid di .streamlit/secrets.toml.")

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    body = {
        "model": "tig/image",
        "prompt": prompt,
        "size": "1024x1024",
        "quality": "medium",
        "n": 1,
    }
    try:
        with post_fn(
            endpoint,
            headers=headers,
            json=body,
            timeout=timeout_s,
            stream=True,
        ) as response:
            if response.status_code == 401:
                raise TrustAPIError("API key Trust tidak sah atau tidak berizin.")
            if response.status_code == 402:
                raise TrustAPIError("Kredit API tidak mencukupi untuk membuat gambar.")
            if response.status_code == 429:
                raise TrustAPIError("Batas permintaan API tercapai. Tunggu lalu coba lagi.")
            if response.status_code >= 400:
                raise TrustAPIError(
                    f"Layanan Trust gagal dengan status HTTP {response.status_code}."
                )
            raw_payload = _read_limited(
                response, MAX_API_RESPONSE_BYTES, "Respons API"
            )
    except requests.Timeout as exc:
        raise TrustAPIError("Waktu permintaan habis. Silakan coba lagi.") from exc
    except requests.RequestException as exc:
        raise TrustAPIError("Koneksi ke layanan Trust gagal. Periksa jaringan.") from exc

    try:
        payload = json.loads(raw_payload)
    except (json.JSONDecodeError, UnicodeDecodeError, TypeError) as exc:
        raise TrustAPIError("Respons API bukan JSON yang valid.") from exc
    if not isinstance(payload, dict):
        raise TrustAPIError("Format respons API tidak valid.")
    return decode_image_response(payload, timeout_s=timeout_s)
